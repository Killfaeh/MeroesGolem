import math
import time
from casioplot import *
from gint import *

SCRN_W=396
SCRN_H=224

LEFT=0
RIGHT=1
CENTER=2

NB_ROW=3
MARGIN=5
PADDING=10
RADIUS=10
DRADIUS=5
BORDER=10
ROW_H=18
HEIGHT=2*RADIUS+2*BORDER+NB_ROW*ROW_H

BORDER_C=C_RGB(31,0,0)
ARROW_C=(0,0,255)
TXT_C=(255,255,255)

MSG_DELAY=0.1

def dRdRect(x1,y1,x2,y2,r,c):
	dcircle(x1+r,y1+r,r,c,C_NONE)
	dcircle(x2-r,y1+r,r,c,C_NONE)
	dcircle(x1+r,y2-r,r,c,C_NONE)
	dcircle(x2-r,y2-r,r,c,C_NONE)
	drect(x1,y1+r,x1+2*r,y2-r,c)
	drect(x2-2*r,y1+r,x2,y2-r,c)
	drect(x1+r,y1,x2-r,y1+2*r,c)
	drect(x1+r,y2-2*r,x2-r,y2,c)
	drect(x1+r,y1+r,x2-r,y2-r,c)

class Message():
	
	def __init__(self,scene,message):
		self.c=BORDER_C
		self.offH=SCRN_H-HEIGHT-MARGIN
		self.scene=scene
		self.message=message
		self.align=LEFT
	
	def plotBG(self):
		dRdRect(MARGIN,self.offH,
				SCRN_W-MARGIN,SCRN_H-MARGIN,
				RADIUS,self.c)
		dRdRect(MARGIN+BORDER,self.offH+BORDER,
				SCRN_W-MARGIN-BORDER,SCRN_H-MARGIN-BORDER,
				DRADIUS,C_BLACK)
	
	def plotLoop(self):
		pt=time.time()
		nt=pt
		l=1
		row=0
		col=0
		
		while l==1:
			nt=time.time()
			if nt > pt+MSG_DELAY:
				drect(MARGIN+BORDER+PADDING,self.offH+BORDER+PADDING,
						SCRN_W-MARGIN-BORDER-PADDING,SCRN_H-MARGIN-BORDER-PADDING,C_BLACK)
				
				nbline=0
				for rowid in range(row):
					line=self.message[rowid]
					if rowid==row-1:
						line=line[:col]
					draw_string(MARGIN+BORDER+PADDING,self.offH+BORDER+PADDING+nbline*ROW_H,line,TXT_C,"medium")
					nbline=nbline+1
				dupdate()
				col=col+1
				if col>len(self.message[row-1]):
					col=0
					row=row+1
					if row>len(self.message):
						l=0
			while 1:
					e = pollevent()
					if e.type == KEYEV_NONE:
						break
					if e.type == KEYEV_DOWN:
						row=len(self.message)-1
						col=len(self.message[row])
						break
		
	def plotMsg(self):
		self.plotLoop()
		draw_string(SCRN_W-MARGIN-PADDING-RADIUS-BORDER,SCRN_H-MARGIN-PADDING-RADIUS-BORDER-int(ROW_H/2),'>',ARROW_C,"medium")
		dupdate()
		getkey()
		self.scene.clear()
		self.scene.resetG()
		self.scene.plotBG()
		self.scene.plotSp()
		dupdate()
	
	def run(self):
		self.plotBG()
		self.plotMsg()

class FlMessage(Message):
	
	def __init__(self,scene,message):
		Message.__init__(self,scene,message)
		self.offH=MARGIN

class Menu(FlMessage):
	
	def __init__(self,scene,menu,title):
		FlMessage.__init__(self,scene,[])
		self.menu=menu
		self.title=title
	
	def plotMsg(self):
		tltw=len(self.title)*11
		tltx=int((SCRN_W-tltw)/2)
		h=2*len(self.menu)-1
		offy=int((SCRN_H-(h+2)*ROW_H)/2)
		draw_string(tltx,offy,self.title,TXT_C,"medium")
		offy=offy+2*ROW_H
		menx=int(SCRN_W/3)
		for m in self.menu:
			draw_string(menx+20,offy,m['lbl'],TXT_C,"medium")
			offy=offy+2*ROW_H
		offy=int((SCRN_H-(h+2)*ROW_H)/2)+2*ROW_H
		l=1
		id=0
		while l==1:
			drect(menx,offy,menx+10,offy+h*ROW_H,C_BLACK)
			draw_string(menx,offy+2*id*ROW_H,'>',ARROW_C,"medium")
			dupdate()
			while 1:
				e = pollevent()
				if e.type == KEYEV_NONE:
					break
				if e.type == KEYEV_DOWN:
					if e.key==KEY_UP:
						id=id-1
						if id<0:
							id=len(self.menu)-1
					elif e.key==KEY_DOWN:
						id=id+1
						if id>=len(self.menu):
							id=0
					elif e.key==KEY_OPTN or e.key==KEY_EXE:
						l=0
						self.scene.clear()
						self.scene.resetG()
						self.scene.plotBG()
						self.scene.plotSp()
						dupdate()
						if self.menu[id]['act']!=None:
							self.menu[id]['act']()
					elif e.key==KEY_EXIT:
						l=0
						self.scene.clear()
						self.scene.resetG()
						self.scene.plotBG()
						self.scene.plotSp()
						dupdate()
					break
	
class SvMenu(Menu):
	
	def __init__(self,scene,title,onSelect):
		Menu.__init__(self,scene,[],title)
		self.onSelect=onSelect
	
	def plotMsg(self):
		tltw=len(self.title)*11
		tltx=int((SCRN_W-tltw)/2)
		h=7
		offy=int((SCRN_H-(h+2)*ROW_H)/2)
		draw_string(tltx,offy,self.title,TXT_C,"medium")
		offy=offy+2*ROW_H
		menx=int(SCRN_W/3)
		for i in range(4):
			lbl='slot {} ['.format(2*i+1)
			if self.scene.game.saves[str(2*i+1)]!=None:
				lbl=lbl+'X'
			else:
				lbl=lbl+' '
			lbl=lbl+']'
			draw_string(40,offy,lbl,TXT_C,"medium")
			lbl='slot {} ['.format(2*i+2)
			if self.scene.game.saves[str(2*i+2)]!=None:
				lbl=lbl+'X'
			else:
				lbl=lbl+' '
			lbl=lbl+']'
			draw_string(int(SCRN_W/2)+20,offy,lbl,TXT_C,"medium")
			offy=offy+2*ROW_H
		offy=int((SCRN_H-(h+2)*ROW_H)/2)+2*ROW_H
		l=1
		row=0
		col=0
		while l==1:
			drect(20,offy,35,offy+h*ROW_H,C_BLACK)
			drect(int(SCRN_W/2),offy,int(SCRN_W/2)+15,offy+h*ROW_H,C_BLACK)
			ax=20
			if col==1:
				ax=int(SCRN_W/2)
			ay=offy+2*row*ROW_H
			draw_string(ax,ay,'>',ARROW_C,"medium")
			dupdate()
			while 1:
				e = pollevent()
				if e.type == KEYEV_NONE:
					break
				if e.type == KEYEV_DOWN:
					if e.key==KEY_UP:
						row=row-1
						if row<0:
							row=3
					elif e.key==KEY_DOWN:
						row=row+1
						if row>3:
							row=0
					elif e.key==KEY_LEFT:
						col=col-1
						if col<0:
							col=1
					elif e.key==KEY_RIGHT:
						col=col+1
						if col>1:
							col=0
					elif e.key==KEY_OPTN or e.key==KEY_EXE:
						l=0
						self.scene.clear()
						self.scene.resetG()
						self.scene.plotBG()
						self.scene.plotSp()
						dupdate()
						if self.onSelect!=None:
							self.onSelect(2*row+col+1)
					elif e.key==KEY_EXIT:
						l=0
						self.scene.clear()
						self.scene.resetG()
						self.scene.plotBG()
						self.scene.plotSp()
						dupdate()
					break

class CfmMenu(Message):
	
	def __init__(self,scene,message,onSelect,slot):
		Message.__init__(self,scene,message)
		self.onSelect=onSelect
		self.slot=slot
	
	def plotMsg(self):
		self.plotLoop()
		draw_string(40,self.offH+BORDER+PADDING+2*ROW_H,'Oui',TXT_C,"medium")
		draw_string(int(SCRN_W/2)+20,self.offH+BORDER+PADDING+2*ROW_H,'Non',TXT_C,"medium")
		l=1
		id=0
		while l==1:
			drect(20,self.offH+BORDER+PADDING+2*ROW_H,35,self.offH+BORDER+PADDING+3*ROW_H,C_BLACK)
			drect(int(SCRN_W/2),self.offH+BORDER+PADDING+2*ROW_H,int(SCRN_W/2)+15,self.offH+BORDER+PADDING+3*ROW_H,C_BLACK)
			ax=20
			if id==1:
				ax=int(SCRN_W/2)
			draw_string(ax,self.offH+BORDER+PADDING+2*ROW_H,'>',ARROW_C,"medium")
			dupdate()
			while 1:
				e = pollevent()
				if e.type == KEYEV_NONE:
					break
				if e.type == KEYEV_DOWN:
					if e.key==KEY_UP or e.key==KEY_LEFT:
						id=id-1
						if id<0:
							id=1
					elif e.key==KEY_DOWN or e.key==KEY_RIGHT:
						id=id+1
						if id>1:
							id=0
					elif e.key==KEY_OPTN or e.key==KEY_EXE:
						l=0
						self.scene.clear()
						self.scene.resetG()
						self.scene.plotBG()
						self.scene.plotSp()
						dupdate()
						if self.onSelect!=None:
							self.onSelect(id,self.slot)
					break