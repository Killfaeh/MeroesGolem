import math
import time
from casioplot import *
from gint import *

from stages import *
#from gui import *
#from bricks import *

class SpriteTest1(Sprite):
	
	def __init__(self):
		Sprite.__init__(self,0,0,22,22)
		self.r=100
		self.w=22
		self.h=22
		self.ang=0
		self.px=self.r*math.cos(self.ang)+SCRN_W/2-self.w/2
		self.py=self.r*math.sin(self.ang)+SCRN_H/2-self.h/2
		self.nx=self.px
		self.ny=self.px
		self.c=C_RGB(31,0,0)
		self.step=math.pi/20
	
	def plot(self):
		dcircle(int(self.nx+self.w/2),int(self.ny+self.h/2),int(self.w/2)-1,self.c,self.c)
	
	def move(self):
		super().move()
		self.ang=self.ang+self.step
		if self.ang>2*math.pi:
			self.ang=self.ang-2*math.pi
		self.nx=self.r*math.cos(self.ang)+SCRN_W/2-self.w/2
		self.ny=self.r*math.sin(self.ang)+SCRN_H/2-self.h/2
	
	def isMoving(self):
		return True

class SceneTest1(Scene):
	
	def __init__(self,game):
		Scene.__init__(self,game,C_RGB(30,30,31),[],[])
		
		self.data=[{'T':E,'cx':72,'cy':66,'rx':79,'ry':70,'fill':[188,214,58]},
					{'T':E,'cx':135,'cy':121,'rx':42,'ry':43,'fill':[109,204,223]},
					{'T':R,'x':167,'y':44,'w':142,'h':64,'fill':[45,84,165]},
					{'T':P,'points':[278,108,311,142,237,213,205,180,278,108],'fill':[237,22,120]},
					{'T':P,'points':[327,18,270,35,268,76,289,126,352,146,382,93,376,41,327,18],'fill':[253,223,78]},
					{'T':R,'x':-6,'y':127,'w':79,'h':112,'fill':[246,138,30]},
					{'T':R,'x':48,'y':172,'w':67,'h':67,'fill':[246,138,30]},
					{'T':R,'x':161,'y':156,'w':161,'h':80,'fill':[246,138,30]},
					{'T':R,'x':282,'y':203,'w':118,'h':36,'fill':[246,138,30]},
					{'T':R,'x':110,'y':86,'w':69,'h':20,'fill':[246,138,30]}]
		
		self.boule=SpriteTest1()
		self.addSprite(self.boule)
	
	def onkeydown(self,e):
		self.stop()
		
class StageTest1(Stage):
	
	def __init__(self,game,player):
		Stage.__init__(self,game,C_RGB(30,30,31),[],[],[],[],player,[],[],{})
		
		self.data=[{'T':E,'cx':72,'cy':66,'rx':79,'ry':70,'fill':[188,214,58]},
					{'T':E,'cx':135,'cy':121,'rx':42,'ry':43,'fill':[109,204,223]},
					{'T':R,'x':167,'y':44,'w':142,'h':64,'fill':[45,84,165]},
					{'T':P,'points':[278,108,311,142,237,213,205,180,278,108],'fill':[237,22,120]},
					{'T':P,'points':[327,18,270,35,268,76,325,78,352,146,382,93,376,41,327,18],'fill':[253,223,78]},
					{'T':R,'x':386,'y':169,'w':15,'h':34,'fill':[254,208,161]},
					{'T':R,'x':212,'y':128,'w':15,'h':34,'fill':[254,208,161]},
					{'T':R,'x':-6,'y':127,'w':79,'h':112,'fill':[246,138,30]},
					{'T':R,'x':48,'y':172,'w':67,'h':67,'fill':[246,138,30]},
					{'T':R,'x':161,'y':156,'w':160,'h':91,'fill':[246,138,30]},
					{'T':R,'x':282,'y':196,'w':124,'h':51,'fill':[246,138,30]},
					{'T':R,'x':110,'y':86,'w':69,'h':20,'fill':[246,138,30]}]
		
		self.items=[]
		self.mobs=[]
		
		self.cols=[{'x':-6,'y':127,'w':79,'h':112},
					{'x':48,'y':172,'w':67,'h':67},
					{'x':161,'y':156,'w':160,'h':91},
					{'x':282,'y':196,'w':124,'h':51},
					{'x':110,'y':86,'w':69,'h':20}]
		
		self.evs=[{'x':386,'y':169,'w':15,'h':34,'ev':StEvent(self.toStage2,None,None,{})},
					{'x':212,'y':128,'w':15,'h':34,'ev':StEvent(None,None,self.coucou,{})}]
	
	def toStage2(self,args):
		self.player.reset(12,141)
		self.game.scenes['stage2'].reset()
		self.game.stop(self.game.scenes['stage2'])
	
	def coucou(self,args):
		coucou=self.getVar('coucou')
		if coucou!=True:
			self.setVar('coucou',True)
			msg=Message(self,["Coucou 1", "Coucou 2", "Coucou 3"])
			msg.run()
		else:
			msg=Message(self,["Tu m'as deja clique dessus !"])
			msg.run()

class StageTest2(Stage):
	
	def __init__(self,game,player):
		Stage.__init__(self,game,C_RGB(30,30,31),[],[],[],[],player,[],[],{})
		
		self.data=[{'T':E,'cx':262,'cy':113,'rx':54,'ry':71,'fill':[129,211,236]},
					{'T':E,'cx':165,'cy':80,'rx':66,'ry':48,'fill':[224,131,182]},
					{'T':E,'cx':38,'cy':70,'rx':22,'ry':23,'fill':[147,143,198]},
					{'T':P,'points':[37,115,22,152,64,211,117,230,194,244,211,204,191,150,83,105,37,115],'fill':[159,215,197]},
					{'T':R,'x':314,'y':-7,'w':95,'h':70,'fill':[212,227,136]},
					{'T':R,'x':264,'y':20,'w':77,'h':51,'fill':[248,246,190]},
					{'T':R,'x':-7,'y':136,'w':15,'h':34,'fill':[254,208,161]},
					{'T':R,'x':205,'y':151,'w':15,'h':34,'fill':[254,208,161]},
					{'T':R,'x':-6,'y':161,'w':134,'h':78,'fill':[246,138,30]},
					{'T':R,'x':91,'y':143,'w':59,'h':104,'fill':[246,138,30]},
					{'T':R,'x':134,'y':179,'w':135,'h':60,'fill':[246,138,30]},
					{'T':R,'x':255,'y':200,'w':79,'h':44,'fill':[246,138,30]},
					{'T':R,'x':320,'y':176,'w':40,'h':72,'fill':[246,138,30]},
					{'T':R,'x':350,'y':135,'w':70,'h':109,'fill':[246,138,30]}]
		
		self.items=[]
		self.mobs=[]
		
		self.cols=[{'x':-6,'y':161,'w':134,'h':78},
					{'x':91,'y':143,'w':59,'h':104},
					{'x':134,'y':179,'w':135,'h':60},
					{'x':255,'y':200,'w':79,'h':44},
					{'x':320,'y':176,'w':40,'h':72},
					{'x':350,'y':135,'w':70,'h':109}]
		
		self.evs=[{'x':-7,'y':136,'w':15,'h':34,'ev':StEvent(self.toStage1,None,None,{})},
					{'x':205,'y':151,'w':15,'h':34,'ev':StEvent(None,None,self.coucou,{})}]
	
	def toStage1(self,args):
		self.player.reset(363,176)
		self.game.scenes['stage1'].reset()
		self.game.stop(self.game.scenes['stage1'])

	def coucou(self,args):
		msg=FlMessage(self,["Coucou 1", "Coucou 2", "Coucou 3"])
		msg.run()

class StageEntreeInt(StageEntree):
	
	def __init__(self,game,player):
		StageEntree.__init__(self,game,player)
		self.items=[]
		self.mobs=[]
		self.cols=[]
		self.evs=[]
	
	def initData(self):
		self.createBGbricks(0,9,20,2,True)
		self.createFGbricks(0,6,20,3,False)
		self.createFGcircles(0,5,20,False)

class StageEntreeCarrf(StageEntree):
	
	def __init__(self,game,player):
		StageEntree.__init__(self,game,player)
		self.items=[]
		self.mobs=[]
		self.cols=[]
		
		self.evs=[{'x':60,'y':80,'w':40,'h':40,'ev':StEvent(self.startEvent,None,None,{'use':False})}]
	
	def initData(self):
		
		self.createBGbricks(0,10,20,5,True)
		#self.createFGbricks(6,8,2,1,True)
		#self.createFGbricks(12,8,2,1,True)
		
		self.createDoor(3,3,'air1',10,11,1)
		self.createDoor(3,10,'feu1',10,3,1)
		self.createDoor(17,3,'eau1',10,3,1)
		self.createDoor(17,10,'terre1',10,10,1)
		self.createDoor(17,6,'gol',2,9,0)
		
		self.createFGcircles(0,3,6,True)
		self.createFGcircles(0,6,6,True)
		self.createFGcircles(14,3,6,True)
		self.createFGcircles(14,6,6,True)
		self.createFGcircles(8,5,4,True)
	
	def startEvent(self,args):
		use=args['use']
		if use!=True:
			args['use']=True
			msg=FlMessage(self,["La region qui entoure le", 
								"site archeologique de Meroe",
								"subit une etrange malediction."])
			msg.run()
			msg=FlMessage(self,["On a retrouve des pillards", 
								"morts dune maladie etrange."])
			msg.run()
			msg=FlMessage(self,["La jeune archeologue Nura", 
								"a decide d'enqueter afin",
								"de resoudre ce mystere."])
			msg.run()

class StageGol(StageEntree):
	
	def __init__(self,game,player):
		StageEntree.__init__(self,game,player)
		self.sprites.append(SleepGol())
		self.mobs=[]
		self.cols=[]
		
		self.evs=[{'x':190,'y':140,'w':40,'h':40,'ev':StEvent(None,None,self.golEvent,{'key':True})}]
	
	def initData(self):
		
		self.createBGbricks(0,9,20,2,True)
		self.createFGbricks(0,6,20,3,False)
		#self.createFGbricks(0,6,7,3,False)
		#self.createFGbricks(13,6,7,3,False)
		
		self.createDoor(2,9,'entreecarrf',17,6,1)
		
		self.createFGcircles(7,5,6,False)
	
	def golEvent(self,args):
		key=args['key']
		if key==True:
			self.player.addToInv('key',1)
			args['key']=False
		gems=self.player.getInv('gem')
		if gems==4:
			msg=Message(self,["Les yeux du gardien se mettent a", 
								"briller, puis il se releve."])
			msg.run()
			msg=Message(self,["Il se retourne en ignorant Nura", 
								"pour se diriger tel un automate",
								"vers la porte des enfers..."])
			msg.run()
			msg=Message(self,["Et combattre les mauvais esprits", 
								"pour les siecles a venir."])
			msg.run()
			msg=FlMessage(self,["Fin provisoire du jeu."])
			msg.run()
			self.game.stop(None)
			# Fin provisoire du jeu
			pass
		else:
			msg=Message(self,["Le gardien de la porte des enfers", 
								"est desactive."])
			msg.run()
			msg=Message(self,["Ce qui explique la malédiction", 
								"qui sevit dans la region."])
			msg.run()
			msg=Message(self,["Il faut retrouver les 4 joyaux", 
								"elementaires pour le reactiver."])
			msg.run()
			msg=Message(self,["Ainsi, le monde sera de nouveau", 
								"protege des mauvais esprits."])
			msg.run()

class StageAir1(StageAir):
	
	def __init__(self,game,player):
		StageAir.__init__(self,game,player)
		self.items=[]
		self.mobs=[]
		self.cols=[]
		self.evs=[]
		
		self.createKey(10,3)
	
	def initData(self):
		
		self.createBGbricks(7,11,6,1,True)
		self.createFGbricks(7,8,6,3,False)
		self.createFGbricks(0,0,4,3,False)
		self.createFGbricks(16,0,4,3,False)
		
		self.createDoor(2,3,'air2',18,10,0)
		self.createDoor(18,3,'air3',2,10,0)
		self.createDoor(10,11,'entreecarrf',3,3,0)
		
		self.createFGcircles(0,3,4,True)
		self.createFGcircles(0,7,4,True)
		self.createFGcircles(16,3,4,True)
		self.createFGcircles(16,7,4,True)
		self.createFGcircles(7,3,6,True)

class StageAir2(StageAir):
	
	def __init__(self,game,player):
		StageAir.__init__(self,game,player)
		self.items=[]
		self.mobs=[]
		self.cols=[]
		self.evs=[]
		
		self.createKey(2,3)
	
	def initData(self):
		
		self.createBGbricks(15,10,5,1,True)
		self.createFGbricks(16,8,4,2,False)
		self.createFGbricks(0,0,4,3,False)
		self.createFGbricks(16,0,4,3,False)
		
		self.createDoor(18,10,'air1',2,3,0)
		
		self.createFGcircles(0,3,4,True)
		self.createFGcircles(0,7,4,True)
		self.createFGcircles(16,3,4,True)
		self.createFGcircles(16,7,4,True)

class StageAir3(StageAir):
	
	def __init__(self,game,player):
		StageAir.__init__(self,game,player)
		self.items=[]
		self.mobs=[]
		self.cols=[]
		self.evs=[]
		
		self.createGem(10,3,100,40)
	
	def initData(self):
		
		#self.createBGbricks(15,10,5,1,True)
		self.createFGbricks(0,7,4,3,False)
		self.createFGbricks(16,7,4,3,False)
		
		self.createDoor(2,10,'air1',18,3,0)
		
		self.createFGcircles(0,6,4,True)
		self.createFGcircles(0,10,4,True)
		self.createFGcircles(16,6,4,True)
		self.createFGcircles(16,10,4,True)
		self.createFGcircles(6,3,8,True)
		self.createFGcircles(6,10,8,True)
		
class StageFeu1(ProcStage):
	
	def __init__(self,game,player):
		ProcStage.__init__(self,game,toRGB((155,50,4)),player)
		self.items=[]
		self.mobs=[]
		self.cols=[]
		self.evs=[]
		
		self.createKey(10,10)
	
	def initData(self):
		
		self.createBGbricks(16,10,4,1,True)
		self.createFGbricks(0,7,4,3,False)
		self.createFGbricks(16,7,4,3,False)
		self.createFGbricks(8,0,4,3,False)
		self.createBGbricks(0,10,4,2,True)
		self.createBGbricks(16,10,4,2,True)
		self.createBGbricks(9,10,2,2,True)
		
		self.createDoor(10,3,'entreecarrf',3,10,0)
		self.createDoor(2,10,'feu2',14,6,0)
		self.createDoor(18,10,'feu3',2,10,0)
		
		self.createFGcircles(0,6,4,True)
		self.createFGcircles(16,6,4,True)
		self.createFGcircles(8,3,4,True)
		

class StageFeu2(ProcStage):
	
	def __init__(self,game,player):
		ProcStage.__init__(self,game,toRGB((155,50,4)),player)
		self.items=[]
		self.mobs=[]
		self.cols=[]
		self.evs=[]
		
		self.createKey(16,9)
	
	def initData(self):
		
		self.createBGbricks(2,10,2,2,True)
		self.createBGbricks(6,10,2,2,True)
		self.createBGbricks(10,10,2,2,True)
		self.createBGbricks(14,10,3,2,True)
		
		self.createDoor(14,6,'feu1',2,10,0)
		
		self.createFGcircles(4,6,13,True)

class StageFeu3(ProcStage):
	
	def __init__(self,game,player):
		ProcStage.__init__(self,game,toRGB((155,50,4)),player)
		self.items=[]
		self.mobs=[]
		self.cols=[]
		self.evs=[]
		
		self.createGem(18,4,80,40)
	
	def initData(self):
		
		self.createBGbricks(0,10,4,2,True)
		self.createFGbricks(0,7,4,3,False)
		self.createFGbricks(16,0,4,4,False)
		
		self.createDoor(2,10,'feu1',18,10,0)
		
		self.createFGcircles(0,6,4,True)
		self.createFGcircles(16,4,4,True)
		self.createFGcircles(6,7,2,True)
		self.createFGcircles(10,7,2,True)
		self.createFGcircles(14,7,2,True)

class StageTerre1(StageTerre):
	
	def __init__(self,game,player):
		StageTerre.__init__(self,game,player)
		self.items=[]
		self.mobs=[]
		self.cols=[]
		self.evs=[]
	
	def initData(self):
		
		self.createFGbricks(0,0,4,3,False)
		self.createFGbricks(0,8,4,3,False)
		self.createFGbricks(16,0,4,3,False)
		self.createFGbricks(16,8,4,3,False)
		self.createFGbricks(7,7,6,3,False)
		
		self.createDoor(2,3,'terre2',18,9,0)
		self.createDoor(18,3,'terre3',2,10,0)
		self.createDoor(10,10,'entreecarrf',17,10,0)
		
		self.createFGcircles(0,3,4,True)
		self.createFGcircles(0,7,4,True)
		self.createFGcircles(0,10,4,True)
		self.createFGcircles(16,3,4,True)
		self.createFGcircles(16,7,4,True)
		self.createFGcircles(16,10,4,True)
		self.createFGcircles(7,6,6,True)
		self.createFGcircles(7,10,6,True)

class StageTerre2(StageTerre):
	
	def __init__(self,game,player):
		StageTerre.__init__(self,game,player)
		self.items=[]
		self.mobs=[]
		self.cols=[]
		self.evs=[]
		
		self.createKey(2,9)
	
	def initData(self):
		
		self.createBGbricks(0,10,4,2,True)
		self.createBGbricks(16,10,4,2,True)
		self.createBGbricks(7,10,2,2,True)
		self.createBGbricks(11,10,2,2,True)
		self.createFGbricks(0,6,4,3,False)
		self.createFGbricks(16,6,4,3,False)
		
		self.createDoor(18,9,'terre1',2,3,0)
		
		self.createFGcircles(0,5,4,True)
		self.createFGcircles(0,9,4,True)
		self.createFGcircles(16,5,4,True)
		self.createFGcircles(16,9,4,True)
		self.createFGcircles(7,9,2,True)
		self.createFGcircles(11,9,2,True)

class StageTerre3(StageTerre):
	
	def __init__(self,game,player):
		StageTerre.__init__(self,game,player)
		self.items=[]
		self.mobs=[]
		self.cols=[]
		self.evs=[]
		
		#self.createKey(16,9)
	
	def initData(self):
		
		self.createFGbricks(0,0,4,3,False)
		self.createFGbricks(0,8,4,3,False)
		self.createFGbricks(16,0,4,3,False)
		self.createFGbricks(16,8,4,3,False)
		
		self.createDoor(2,10,'terre1',18,3,0)
		
		self.createFGcircles(0,3,4,True)
		self.createFGcircles(0,7,4,True)
		self.createFGcircles(0,10,4,True)
		self.createFGcircles(16,3,4,True)
		self.createFGcircles(16,7,4,True)
		self.createFGcircles(16,10,4,True)
		self.createFGcircles(7,7,6,True)
		
		self.createGem(18,3,100,120)

class StageEau1(StageEau):
	
	def __init__(self,game,player):
		StageEau.__init__(self,game,player)
		self.items=[]
		self.mobs=[]
		self.cols=[]
		self.evs=[]
		
		self.createKey(10,10)
	
	def initData(self):
		
		self.createBGbricks(16,10,4,1,True)
		self.createFGbricks(0,7,4,3,False)
		self.createFGbricks(16,7,4,3,False)
		self.createFGbricks(8,0,4,3,False)
		self.createBGbricks(0,10,4,2,True)
		self.createBGbricks(16,10,4,2,True)
		self.createBGbricks(9,10,2,2,True)
		
		self.createDoor(10,3,'entreecarrf',17,3,0)
		self.createDoor(2,10,'eau2',14,6,0)
		self.createDoor(18,10,'eau3',14,6,0)
		
		self.createFGcircles(0,6,4,True)
		self.createFGcircles(16,6,4,True)
		self.createFGcircles(8,3,4,True)
		

class StageEau2(StageEau):
	
	def __init__(self,game,player):
		StageEau.__init__(self,game,player)
		self.items=[]
		self.mobs=[]
		self.cols=[]
		self.evs=[]
		
		self.createKey(16,9)
	
	def initData(self):
		
		self.createBGbricks(2,10,2,2,True)
		self.createBGbricks(6,10,2,2,True)
		self.createBGbricks(10,10,2,2,True)
		self.createBGbricks(14,10,3,2,True)
		
		self.createDoor(14,6,'eau1',2,10,0)
		
		self.createFGcircles(4,6,13,True)

class StageEau3(StageEau):
	
	def __init__(self,game,player):
		StageEau.__init__(self,game,player)
		self.items=[]
		self.mobs=[]
		self.cols=[]
		self.evs=[]
		
		self.createGem(18,4,80,120)
	
	def initData(self):
		
		self.createBGbricks(0,10,4,2,True)
		self.createFGbricks(0,7,4,3,False)
		self.createFGbricks(16,0,4,4,False)
		
		self.createDoor(2,10,'eau1',18,10,0)
		
		self.createFGcircles(0,6,4,True)
		self.createFGcircles(16,4,4,True)
		self.createFGcircles(6,7,2,True)
		self.createFGcircles(10,7,2,True)
		self.createFGcircles(14,7,2,True)
		