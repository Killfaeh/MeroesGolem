import math
import time
from casioplot import *
from gint import *

from imgsprites import *
from imgsprites2 import *

SCRN_W=396
SCRN_H=224
FPS=24
DELAY=1/FPS

WLK=5
JMP=15

class Sprite():
	
	def __init__(self,x,y,w,h):
		self.px=x
		self.py=y
		self.nx=x
		self.ny=y
		self.w=w
		self.h=h
	
	def vx(self):
		return self.nx-self.px
	
	def vy(self):
		return self.ny-self.py
	
	def pbb(self):
		return [int(round(self.px)),int(round(self.py)),int(round(self.px+self.w)),int(round(self.py+self.h))]
	
	def nbb(self):
		return [int(round(self.nx))-1,int(round(self.ny))-1,int(round(self.nx+self.w))+2,int(round(self.ny+self.h))+2]
	
	def phybb(self):
		return [int(round(self.nx)),int(round(self.ny)),int(round(self.nx+self.w)),int(round(self.ny+self.h))]
	
	def clear(self,c):
		drect(int(round(self.nx)),int(round(self.ny)),int(round(self.nx+self.w)),int(round(self.ny+self.h)),c)
	
	# A surcharger
	def plot(self):
		pass
	
	# A surcharger
	def move(self):
		self.px=self.nx
		self.py=self.ny
	
	# A surcharger
	def isMoving(self):
		move=False
		if self.px!=self.nx or self.py!=self.ny:
			move=True
		return move
	
	# A surcharger
	def getData(self):
		return {'t':None,'x':self.nx,'y':self.ny,'w':self.w,'h':self.h}
	
	# A surcharger
	def loadData(self,data):
		self.px=data['x']
		self.py=data['y']
		self.nx=data['x']
		self.ny=data['y']
		self.w=data['w']
		self.h=data['h']

class SleepGol(Sprite):
	
	def __init__(self):
		Sprite.__init__(self,200,160,20,20)
	
	def isMoving(self):
		return False
	
	def plot(self):
		dsubimage(self.nx,self.ny,imgsprites2,0,0,20,20)

class SpKey(Sprite):
	
	def __init__(self,x,y):
		Sprite.__init__(self,x,y,20,20)
	
	def isMoving(self):
		return False
	
	def plot(self):
		dsubimage(self.nx,self.ny,imgsprites2,20,0,20,20)

class SpGem(Sprite):
	
	def __init__(self,x,y,sx,sy):
		Sprite.__init__(self,x,y,20,20)
		self.sx=sx
		self.sy=sy
	
	def isMoving(self):
		return False
	
	def plot(self):
		dsubimage(self.nx,self.ny,imgsprites,self.sx,self.sy,20,20)

class SpMobPlt():
	
	def __init__(self,x,y,c):
		Sprite.__init__(self,x,y,40,20)
		self.c=c
	
	def plot(self):
		drect(self.nx,self.ny,self.nx+self.w,self.ny+self.h,self.c)
		pass
	
	def isMoving(self):
		return True

class AnimSp(Sprite):
	
	def __init__(self,x,y,w,h):
		Sprite.__init__(self,x,y,w,h)
		self.anim=[] # Tableau qui contient des tableaux qui correspondent chacun à une animation et contiennent une liste de coordonnées sur la sprite sheet
		self.delays=[] # Délais de changement de frame
		self.loop=[]
		self.next=[]
		self.animId=0
		self.frame=0
		self.pt=time.time()
		self.nt=self.pt
	
	def plot(self):
		self.nt=time.time()
		anim=self.anim[self.animId]
		if self.nt>=self.pt+DELAY:
			self.pt=self.nt
			self.frame=self.frame+1
			if self.frame>=len(anim):
				self.frame=0
				if self.loop[self.animId]!=True:
					self.animId=self.next[self.animId]
		frame=anim[self.frame]
		if frame[0]!=None and frame[1]!=None:
			dsubimage(self.nx,self.ny,imgsprites,frame[0],frame[1],self.w,self.h)
	
	def setAnim(self,id):
		self.animId=id
		self.frame=0
		self.pt=time.time()
		self.nt=self.pt

class Player(AnimSp):
	
	def __init__(self,x,y,w,h):
		AnimSp.__init__(self,x,y,w,h)
		self.hp=100
		self.wlk=0
		self.jmp=0
		self.dir=0
		self.animId=2
		self.events=[]
		self.inv={}
		# Ajouter animations
		# Ajouter attaque pour le golem et les mobs
	
	def getType(self):
		return 'ply'
	
	def phybb(self):
		return [int(round(self.nx))+10,int(round(self.ny))+5,int(round(self.nx+self.w))-5,int(round(self.ny+self.h))]
	
	'''
	def plot(self):
		super().plot()
		drect(int(self.nx),int(self.ny),int(self.nx+self.w),int(self.ny+self.h),C_RGB(31,0,0))
		#dsubimage(self.nx,self.ny,imgsprites,sx,sy,self.w,self.h)
	'''
	
	def walkToRight(self):
		self.dir=0
		self.wlk=WLK
		self.frame=0
		if abs(self.jmp)<=1:
			self.animId=0
		else:
			self.animId=4
	
	def walkToLeft(self):
		self.dir=1
		self.wlk=-WLK
		self.frame=0
		if abs(self.jmp)<=1:
			self.animId=1
		else:
			self.animId=5
	
	def stopWlk(self):
		self.wlk=0
		self.frame=0
		if abs(self.jmp)<=1:
			if self.dir==0:
				self.animId=2
			else:
				self.animId=3
		else:
			if self.dir==0:
				self.animId=4
			else:
				self.animId=5
	
	def jump(self):
		if abs(self.jmp)<=1:
			self.jmp=-JMP
			self.frame=0
			if self.dir==0:
				self.animId=4
			else:
				self.animId=5
	
	# A surcharger
	def attck(self):
		pass
	
	def reset(self,x,y):
		self.wlk=0
		self.jmp=0
		self.events=[]
		self.px=x
		self.py=y
		self.nx=x
		self.ny=y
	
	def move(self):
		super().move()
		if self.wlk!=0:
			self.nx=self.nx+self.wlk
		self.jmp=self.jmp+1
		self.ny=self.ny+self.jmp
	
	def isMoving(self):
		mv=False
		if self.wlk!=0 or self.jmp!=0:
			mv=True
		return mv
	
	def isOverEvent(self,ev):
		isov=False
		if ev in self.events:
			isov=True
		return isov
	
	def addEvent(self,ev):
		if ev not in self.events:
			self.events.append(ev)
	
	def rmEvent(self,ev):
		if ev in self.events:
			index = self.events.index(ev)
			del self.events[index]
	
	def addHp(self,hp):
		self.hp=self.hp+hp
		if self.hp>100:
			self.hp=100
		
	def rmHp(self,hp):
		self.hp=self.hp-hp
		if self.hp<0:
			self.hp=0
			# Envoyer un game over
		
	def getInv(self,n):
		try:
			return self.inv[n]
		except KeyError:
			return 0
	
	def addToInv(self,n,qt):
		try:
			it=self.inv[n]
			self.inv[n]=it+qt
		except KeyError:
			self.inv[n]=qt
	
	def rmFromInv(self,n,qt):
		try:
			it=self.inv[n]
			self.inv[n]=it-qt
			if self.inv[n]<0:
				self.inv[n]=0
		except KeyError:
			self.inv[n]=0
	
	def getData(self):
		return {'t':'ply','x':self.nx,'y':self.ny,'w':self.w,'h':self.h,'dir':self.dir,'inv':self.inv}
	
	def loadData(self,data):
		self.px=data['x']
		self.py=data['y']
		self.nx=data['x']
		self.ny=data['y']
		self.w=data['w']
		self.h=data['h']
		self.dir=data['dir']
		self.inv=data['inv']

class Nura(Player):
	
	def __init__(self,x,y):
		Player.__init__(self,x,y,20,20)
		
		self.anim=[[(0,0),(20,0),(40,0),(60,0),(80,0),(100,0)],
					[(0,20),(20,20),(40,20),(60,20),(80,20),(100,20)],
					[(0,40)],[(20,40)],[(40,40)],[(60,40)]]
		
		self.delays=[0.1,0.1,0.1,0.1,0.1,0.1]
		self.loop=[True,True,True,True,True,True]
		self.next=[2,3,2,3,2,3]
	
	def getType(self):
		return 'nur'
	
	def getData(self):
		return {'t':'nur','x':self.nx,'y':self.ny,'w':self.w,'h':self.h,'dir':self.dir,'inv':self.inv}

class Golem(Player):
	
	def __init__(self,x,y):
		Player.__init__(self,x,y,20,20)
		
		self.anim=[[(0,60),(20,60),(40,60),(60,60),(80,60),(100,60)],
					[(0,80),(20,80),(40,80),(20,80),(60,80),(100,80),(80,80),(100,80)],
					[(0,120)],[(20,120)],[(40,120)],[(60,120)],
					[(0,100),(20,100),(40,100)],
					[(60,100),(80,100),(100,100)]]
		
		self.delays=[0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1]
		self.loop=[True,True,True,True,True,True,False,False]
		self.next=[2,3,2,3,2,3,2,3]
	
	def getType(self):
		return 'gol'
	
	def attck(self):
		self.frame=0
		if self.dir==0:
			self.animId=6
		else:
			self.animId=7
	
	def getData(self):
		return {'t':'gol','x':self.nx,'y':self.ny,'w':self.w,'h':self.h,'dir':self.dir,'inv':self.inv}

class Mob(AnimSp):
	
	def __init__(self,x,y):
		AnimSp.__init__(self,x,y,20,20)
		self.hp=3
		
		self.anim=[[(0,140),(20,140),(40,140),(60,140),(80,140),(100,140)],
					[(0,160),(20,160),(40,160),(60,160),(80,160),(100,160)],
					[(20,140)],[(20,160)],
					[(0,100),(20,100),(40,100)],
					[(60,100),(80,100),(100,100)]]
		
		self.delays=[0.1,0.1,0.1,0.1,0.1,0.1]
		self.loop=[True,True,True,True,False,False]
		self.next=[2,3,2,3,2,3]
	
	def phybb(self):
		return [int(round(self.nx)),int(round(self.ny)),int(round(self.nx+self.w)),int(round(self.ny+self.h))]
	
	def walkToRight(self):
		self.dir=0
		self.wlk=WLK
		self.animId=0
		self.frame=0
	
	def walkToLeft(self):
		self.dir=1
		self.wlk=-WLK
		self.animId=1
		self.frame=0
	
	def attck(self):
		self.frame=0
		if self.dir==0:
			self.animId=4
		else:
			self.animId=5
	
	def getData(self):
		return {'t':'mob','x':self.nx,'y':self.ny,'w':self.w,'h':self.h,'dir':self.dir,'inv':self.inv}

class FlammeSp(AnimSp):
	
	def __init__(self,x,y):
		AnimSp.__init__(self,x,y,20,40)
		self.anim=[[(None,None),(120,0),(120,40),(120,80),(120,120),(120,160),(120,40),(120,0)]]
		self.delays=[0.1]
		self.loop=[True]
		self.next=[0]
	
	def phybb(self):
		return [int(round(self.nx)),int(round(self.ny)),int(round(self.nx+self.w)),int(round(self.ny+self.h))]

class GeyserSp(AnimSp):
	
	def __init__(self,x,y):
		AnimSp.__init__(self,x,y,20,40)
		self.anim=[[(None,None),(140,0),(140,40),(140,80),(140,120),(140,160),(140,40),(140,0)]]
		self.delays=[0.1]
		self.loop=[True]
		self.next=[0]
	
	def phybb(self):
		return [int(round(self.nx)),int(round(self.ny)),int(round(self.nx+self.w)),int(round(self.ny+self.h))]

class GemSp(Sprite):
	
	def __init__(self,x,y,sx,sy):
		Sprite.__init__(self,x,y,20,20)
		self.sx=sx
		self.sy=sy
		self.disp=True
	
	def plot(self):
		if self.disp==True:
			dsubimage(self.nx,self.ny,imgsprites,self.sx,self.sy,self.w,self.h)

class GemFeu(GemSp):
	
	def __init__(self,x,y):
		GemSp.__init__(self,x,y,80,40)

class GemAir(GemSp):
	
	def __init__(self,x,y):
		GemSp.__init__(self,x,y,100,40)

class GemEau(GemSp):
	
	def __init__(self,x,y):
		GemSp.__init__(self,x,y,80,120)

class GemTer(GemSp):
	
	def __init__(self,x,y):
		GemSp.__init__(self,x,y,100,120)
			
# Sprite de type qui se déplace
# Sprite animé
# Sprite mob
# Sprite item
# Boulets
# Plateformes mobiles