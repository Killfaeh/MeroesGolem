
#from engine import *
from data import *

class Game():
	
	def __init__(self):
		self.saves={'1':None,'2':None,'3':None,'4':None,'5':None,'6':None,'7':None,'8':None}
		self.nura=Nura(20,100)
		self.golem=Golem(20,100)
		self.player=self.nura
		
		self.scenes={'entreeint': StageEntreeInt(self,self.nura),
						'entreecarrf': StageEntreeCarrf(self,self.nura),
						'gol': StageGol(self,self.nura),
						'air1': StageAir1(self,self.nura),
						'air2': StageAir2(self,self.nura),
						'air3': StageAir3(self,self.nura),
						'feu1': StageFeu1(self,self.nura),
						'feu2': StageFeu2(self,self.nura),
						'feu3': StageFeu3(self,self.nura),
						'terre1': StageTerre1(self,self.nura),
						'terre2': StageTerre2(self,self.nura),
						'terre3': StageTerre3(self,self.nura),
						'eau1': StageEau1(self,self.nura),
						'eau2': StageEau2(self,self.nura),
						'eau3': StageEau3(self,self.nura)}
		
		self.currentScene=self.scenes['entreecarrf']
	
	def resetG(self):
		self.currentScene.clear()
		self.currentScene.resetG()
		self.currentScene.plotBG()
		self.currentScene.plotSp()
	
	def gameOver(self):
		# Il faudra retourner l'écran de game over
		return None
	
	def mainMenu(self):
		# Retourner la scène du menu principal
		return None
	
	def loadMenu(self):
		self.resetG()
		menu=SvMenu(self.currentScene,"Charger une partie",self.load)
		menu.run()
	
	def saveMenu(self):
		self.resetG()
		menu=SvMenu(self.currentScene,"Sauvegarder la partie",self.cfSave)
		menu.run()
	
	def saved(self,conf,slot):
		self.resetG()
		dupdate()
		if conf==0:
			self.save(slot)
			msg=Message(self.currentScene,["Partie sauvegardee !"])
			msg.run()
		else:
			self.saveMenu()
			
	def cfSave(self,slot):
		self.resetG()
		if self.saves[str(slot)]!=None:
			menu=CfmMenu(self.currentScene,["Il y a deja une partie dans ce slot.","Veux-tu l'ecraser ?"],self.saved,slot)
			menu.run()
		else:
			self.saved(0,slot)
	
	def run(self):
		with open("saves.dat", "a") as f:
			#Init
			pass
		ct=''
		with open("saves.dat", "r") as f:
			ct=f.read()
			if ct!='':
				self.saves=eval(ct)
		if ct=='':
			with open("saves.dat", "w") as f:
				nc=f.write(str(self.saves))
		self.currentScene.run()
	
	def stop(self,nextScene):
		if self.currentScene!=None:
			self.currentScene.stop(nextScene)
			self.currentScene=nextScene
	
	def pause(self):
		self.resetG()
		options=[{'lbl':'Retour','act':None},
					{'lbl':'Charger','act':self.loadMenu},
					{'lbl':'Sauvegarder','act':self.saveMenu},
					{'lbl':'Quitter','act':self.quit}]
		menu=Menu(self.currentScene,options,"Menu pause")
		menu.run()
	
	def quit(self):
		self.stop(None)
	
	def save(self,slot):
		data={'nur':self.nura.getData(),'gol':self.golem.getData(),'curply':self.player.getType(),'cur':None,'scenes':{}}
		for key,sc in self.scenes.items():
			data['scenes'][key]=sc.getData()
			if sc==self.currentScene:
				data['cur']=key
		self.saves[str(slot)]=data
		with open("saves.dat", "w") as f:
			nc=f.write(str(self.saves))
	
	def load(self,slot):
		data=self.saves[str(slot)]
		if data!=None:
			self.nura.loadData(data['nur'])
			self.golem.loadData(data['gol'])
			if data['curply']=='gol':
				self.player=self.golem
			else:
				self.player=self.nura
			for key,sc in data['scenes'].items():
				self.scenes[key].loadData(sc)
			self.stop(self.scenes[data['cur']])

game=Game()
game.run()