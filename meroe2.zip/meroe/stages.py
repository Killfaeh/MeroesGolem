import math
import time
from casioplot import *
from gint import *

from engine import *
from gui import *
from bricks import *

class Stage(Scene):
	
	def __init__(self,game,c,data,items,mobs,mobgd,player,cols,evs,vars):
		Scene.__init__(self,game,c,data,[])
		self.items=items
		self.mobs=mobs
		self.mobgd=mobgd
		for item in items:
			self.addSprite(item)
		for mob in mobs:
			self.addSprite(mob)
		for mob in mobgd:
			self.addSprite(mob)
		self.player=player
		self.addSprite(player)
		self.cols=cols
		self.evs=evs
		self.isinit=False
		self.vars=vars

	def addItem(self,it):
		if it not in self.items:
			self.items.append(it)
		self.addSprite(it)
	
	def rmItem(self,it):
		if it in self.items:
			index = self.items.index(it)
			del self.items[index]
		self.rmSprite(it)
	
	def addMob(self,mob):
		if mob not in self.mobs:
			self.mobs.append(mob)
		self.addSprite(mob)
	
	def rmMob(self,mob):
		if mob in self.mobs:
			index = self.mobs.index(mob)
			del self.mobs[index]
		self.rmSprite(mob)
	
	def initBB(self):
		super().initBB()
		for el in self.cols:
			el['BB']=[el['x'],el['y'],el['x']+el['w'],el['y']+el['h']]
		for el in self.evs:
			el['BB']=[el['x'],el['y'],el['x']+el['w'],el['y']+el['h']]
		self.game.player=self.player


	def sim(self):
		super().sim()
		if self.player.nx<0:
			self.player.nx=0
		elif self.player.nx+self.player.w>SCRN_W:
			self.player.nx=SCRN_W-self.player.w
		if self.player.ny>SCRN_H:
			self.nextScene=self.game.gameOver()
			self.l=0
		vx=self.player.vx()
		vy=self.player.vy()
		for el in self.cols:
			pbb=self.player.phybb() # Récupérer la bounding box physique à la place
			elbb=el['BB']
			col=self.testBB(el,self.player)
			if col==True:
				dx=0
				dy=0
				if vx<0:
					dx=abs(elbb[2]-self.player.nx)
				elif vx>0:
					dx=abs(self.player.nx+self.player.w-elbb[0])
				if vy<0:
					dy=abs(elbb[3]-self.player.ny)
				elif vy>0:
					dy=abs(self.player.ny+self.player.h-elbb[1])
				if self.player.wlk!=0 and dx<=WLK:
					if vx<0:
						self.player.nx=elbb[2]
					elif vx>0:
						self.player.nx=elbb[0]-self.player.w
				if self.player.jmp!=0 and dy<=abs(self.player.jmp):
					if vy<0:
						self.player.jmp=0
						self.player.ny=elbb[3]
					else:
						self.player.jmp=0
						self.player.ny=elbb[1]-self.player.h
		# mobgd
		'''
		for el in self.mobgd:
			pbb=self.player.phybb() # Récupérer la bounding box physique à la place
			elbb=el.phybb()
			col=self.testBB(el,self.player)
			if col==True:
				dx=0
				dy=0
				if vx<0:
					dx=abs(elbb[2]-self.player.nx)
				elif vx>0:
					dx=abs(self.player.nx+self.player.w-elbb[0])
				if vy<0:
					dy=abs(elbb[3]-self.player.ny)
				elif vy>0:
					dy=abs(self.player.ny+self.player.h-elbb[1])
				if self.player.wlk!=0 and dx<=WLK:
					if vx<0:
						self.player.nx=elbb[2]
					elif vx>0:
						self.player.nx=elbb[0]-self.player.w
				if self.player.jmp!=0 and dy<=abs(self.player.jmp):
					if vy<0:
						self.player.jmp=0
						self.player.ny=elbb[3]
					else:
						self.player.jmp=0
						self.player.ny=elbb[1]-self.player.h
		'''
		# Ajouter collisions avec boulets
		# Ajouter collisions avec mobs
		# Ajouter collisions avec plateformes mobiles (/!\ Gérer l'addition des vitesses /!\)
		# Ajouter collisions avec flammes et geysers
		for el in self.evs:
			pbb=self.player.nbb()
			elbb=el['BB']
			col=self.testBB(el,self.player)
			if col==True:
				if el['ev']!=None:
					if self.player.isOverEvent(el['ev'])!=True:
						el['ev'].enter()
						self.player.addEvent(el['ev'])
			else:
				if el['ev']!=None:
					if self.player.isOverEvent(el['ev'])==True:
						el['ev'].out()
						self.player.rmEvent(el['ev'])
		return None # Retourner une instruction pour mettre à jour une donnée ou passer à un autre écran
	
	def redraw(self):
		super().redraw()
		# Afficher la barre de vie
	
	def onkeydown(self,e):
		if e.key==KEY_LEFT:
			self.player.walkToLeft()
		elif e.key==KEY_RIGHT:
			self.player.walkToRight()
		elif e.key==KEY_SHIFT:
			self.player.jump()
		elif e.key==KEY_ALPHA:
			self.player.attck()
		elif e.key==KEY_OPTN or e.key==KEY_EXE:
			for el in self.player.events:
				el.action()
		elif e.key==KEY_EXIT or e.key==KEY_MENU:
			self.game.pause()
	
	def onkeyup(self,e):
		if e.key==KEY_LEFT or e.key==KEY_RIGHT:
			self.player.stopWlk()
	
	def getVar(self,n):
		try:
			return self.vars[n]
		except KeyError:
			return None
	
	def setVar(self,n,val):
		self.vars[n]=val
	
	def getData(self):
		data={'t':None,'spt':[],'vars':self.vars}
		for sp in self.sprites:
			spdat=sp.getData()
			if spdat['t']!='ply':
				data['spt'].append(sp.getData())
		return data
	
	def loadData(self,data):
		self.sprites=[]
		self.vars=data['vars']
		for sp in data['spt']:
			# A décider si on réinitialise à chaque fois qu'on entre dans la map ou pas
			if sp['t']=='it':
				nsp=Sprite(0,0,20,20)
				nsp.loadData(sp)
				self.addItem(nsp)
			# A décider si on réinitialise à chaque fois qu'on entre dans la map ou pas
			elif sp['t']=='mob':
				nsp=Sprite(0,0,20,20)
				nsp.loadData(sp)
				self.addMob(nsp)
			elif sp['t']!='ply' and sp['t']!='nur' and sp['t']!='gol':
				nsp=Sprite(0,0,20,20)
				nsp.loadData(sp)
				self.addSprite(nsp)
		self.addSprite(self.player)

class ProcStage(Stage):
	
	def __init__(self,game,c,player):
		Stage.__init__(self,game,c,[],[],[],[],player,[],[],[])
		# Couleurs de la zone feu par défaut
		self.sy=20
		self.ctiles1=toRGB((200,66,8))
		self.ctiles2=toRGB((255,193,160))
		self.palette=[(220,129,72),(210,154,119)]
	
	def createBGbricks(self,x,y,w,h,phy):
		self.data=self.data+genBricks(x,y,w,h,0,self.sy)
		if phy==True:
			self.cols=self.cols+genRect(x*TILE,y*TILE,w*TILE,h*TILE,None)
	
	def createFGbricks(self,x,y,w,h,phy):
		self.data=self.data+genBricks(x,y,w,h,20,self.sy)
		if phy==True:
			self.cols=self.cols+genRect(x*TILE,y*TILE,w*TILE,h*TILE,None)
	
	def createBGcircles(self,x,y,w,phy):
		self.data=self.data+genCircles(x,y,w,40,self.sy,self.ctiles1)
		if phy==True:
			self.cols=self.cols+genRect(x*TILE-4,y*TILE-4,w*TILE,TILE+8,None)
	
	def createFGcircles(self,x,y,w,phy):
		self.data=self.data+genCircles(x,y,w,60,self.sy,self.ctiles2)
		if phy==True:
			self.cols=self.cols+genRect(x*TILE-4,y*TILE-4,w*TILE,TILE+8,None)
	
	def createDoor(self,x,y,target,xp,yp,keys):
		self.data=self.data+genDoor(x,y)
		self.evs.append({'x':x*TILE-TILE,'y':y*TILE-2*TILE,'w':2*TILE,'h':2*TILE,'ev':StEvent(None,None,self.throwDoor,{'target':target,'xp':xp,'yp':yp,'keys':keys,'open':False})})
	
	def createKey(self,x,y):
		spKey=SpKey(x*TILE-TILE,y*TILE-2*TILE)
		self.sprites.append(spKey)
		self.evs.append({'x':x*TILE-TILE,'y':y*TILE-2*TILE,'w':2*TILE,'h':2*TILE,'ev':StEvent(None,None,self.getKey,{'key':True,'sp':spKey})})
	
	def createGem(self,x,y,sx,sy):
		spGem=SpGem(x*TILE-TILE,y*TILE-2*TILE,sx,sy)
		self.sprites.append(spGem)
		self.evs.append({'x':x*TILE-TILE,'y':y*TILE-2*TILE,'w':2*TILE,'h':2*TILE,'ev':StEvent(None,None,self.getGem,{'gem':True,'sp':spGem})})
	
	def throwDoor(self,args):
		pkeys=self.player.getInv('key')
		if args['open']==True or pkeys>=args['keys']:
			if args['open']==False:
				self.player.rmFromInv('key',args['keys'])
			args['open']=True
			self.player.reset(args['xp']*TILE-DTILE,args['yp']*TILE-TILE-5)
			self.game.scenes[args['target']].reset()
			self.game.stop(self.game.scenes[args['target']])
		else:
			msg=Message(self,["Il faut une clef", "pour franchir cette porte."])
			msg.run()
	
	def getKey(self,args):
		key=args['key']
		if key==True:
			args['key']=False
			self.player.addToInv('key',1)
			self.rmSprite(args['sp'])
			msg=Message(self,["Vous avez recupere", "une clef."])
			msg.run()
	
	def getGem(self,args):
		key=args['gem']
		if key==True:
			args['gem']=False
			self.player.addToInv('gem',1)
			self.rmSprite(args['sp'])
			msg=Message(self,["Vous avez recupere", "un joyaux elementaire."])
			msg.run()
	
	# A surcharger
	def initData(self):
		self.data=[]
	
	def run(self):
		self.init=False
		self.initData()
		super().run()
		
	def stop(self,nextScene):
		self.data=[]
		self.torefresh=[]
		super().stop(nextScene)
		
class StageEntree(ProcStage):
	
	def __init__(self,game,player):
		ProcStage.__init__(self,game,toRGB((128,61,19)),player)
		self.sy=0
		self.ctiles1=toRGB((255,196,138))
		self.ctiles2=toRGB((255,196,138))
		self.palette=[(220,129,72),(210,154,119)]

class StageAir(ProcStage):
	
	def __init__(self,game,player):
		ProcStage.__init__(self,game,toRGB((196,237,255)),player)
		self.sy=40
		self.ctiles1=toRGB((238,239,239))
		self.ctiles2=toRGB((238,239,239))
		self.palette=[(130,137,140),(187,193,196)]

class StageEau(ProcStage):
	
	def __init__(self,game,player):
		ProcStage.__init__(self,game,toRGB((45,88,102)),player)
		self.sy=60
		self.ctiles1=toRGB((81,125,138))
		self.ctiles2=toRGB((177,219,229))


class StageTerre(ProcStage):
	
	def __init__(self,game,player):
		ProcStage.__init__(self,game,toRGB((97,90,64)),player)
		self.sy=80
		self.ctiles1=toRGB((136,124,94))
		self.ctiles2=toRGB((177,219,229))
		self.palette=[(199,157,89),(201,182,150)]

class StageFin(ProcStage):
	
	def __init__(self,game,player):
		ProcStage.__init__(self,game,toRGB((9,98,98)),player)
		self.sy=100
		self.ctiles1=toRGB((84,137,122))
		self.ctiles2=toRGB((255,226,178))
		self.palette=[(199,157,89),(201,182,150)]

class StEvent():
	
	def __init__(self,onEnter,onOut,onAction,args):
		self.onEnter=onEnter
		self.onOut=onOut
		self.onAction=onAction
		self.args=args
	
	def enter(self):
		if self.onEnter!=None:
			self.onEnter(self.args)
	
	def out(self):
		if self.onOut!=None:
			self.onOut(self.args)
	
	def action(self):
		if self.onAction!=None:
			self.onAction(self.args)
