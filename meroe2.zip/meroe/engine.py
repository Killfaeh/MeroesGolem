import math
import time
from casioplot import *
from gint import *

from sprites import *

SCRN_W=396
SCRN_H=224
FPS=24
DELAY=1/FPS

X=0
R=1
L=2
C=3
E=4
P=5
I=6

def cvtChan(c):
	return int(round(c/255*31))

def toRGB(c):
	return C_RGB(cvtChan(c[0]),cvtChan(c[1]),cvtChan(c[2]))

class Scene():

	def __init__(self,game,c,data,sprites):
		self.game=game
		self.nextScene=None
		self.l=0
		self.c=c
		self.data=data
		self.torefresh=data
		self.nbref=len(self.torefresh)
		self.sprites=sprites
		self.isinit=False
	
	def initBB(self):
		if self.isinit!=True:
			for el in self.data:
				index=self.data.index(el)
				if el['T']==X:
					el['BB']=[el['x'],el['y'],el['x'],el['y']]
				elif el['T']==R or el['T']==I:
					el['BB']=[el['x'],el['y'],el['x']+el['w'],el['y']+el['h']]
				elif el['T']==L:
					el['BB']=[min(el['x1'],el['x2']),min(el['y1'],el['y2']),max(el['x1'],el['x2']),max(el['y1'],el['y2'])]
				elif el['T']==C:
					el['BB']=[el['cx']-el['r'],el['cy']-el['r'],el['cx']+el['r'],el['cy']+el['r']]
				elif el['T']==E:
					el['BB']=[el['cx']-el['rx'],el['cy']-el['ry'],el['cx']+el['rx'],el['cy']+el['ry']]
				elif el['T']==P:
					vx=[]
					vy=[]
					i=0
					for v in el['points']:
						if i%2==0:
							vx.append(v)
						else:
							vy.append(v)
						i=i+1
					el['BB']=[min(vx),min(vy),max(vx),max(vy)]
				try:
					oc=el['fill']
					el['fill']=toRGB(oc)
				except KeyError:
					el['fill']=C_NONE
				except TypeError:
					pass
				try:
					oc=el['bord']
					el['bord']=toRGB(oc)
				except KeyError:
					el['bord']=C_NONE
				except TypeError:
					pass
				el['show']=True
			self.isinit=True
	
	def addSprite(self,sp):
		if sp is not None and sp not in self.sprites:
			self.sprites.append(sp)
	
	def rmSprite(self,sp):
		if sp in self.sprites:
			index = self.sprites.index(sp)
			del self.sprites[index]
	
	def vInBB(self,v,bb):
		col=False
		if v[0]>bb[0] and v[0]<bb[2] and v[1]>bb[1] and v[1]<bb[3]:
			col=True
		return col
	
	def testBB(self,el,sp):
		col=False
		elbb=el['BB']
		spbb=[0,0,0,0]
		if isinstance(sp, Sprite):
			spbb=sp.nbb()
		else:
			spbb=sp['BB']
		vt=[[spbb[0],spbb[1]],[spbb[0],spbb[3]],[spbb[2],spbb[1]],[spbb[2],spbb[3]]]
		for v in vt:
			if self.vInBB(v, elbb):
				col=True
				break
		if col!=True:
			vt=[[elbb[0],elbb[1]],[elbb[0],elbb[3]],[elbb[2],elbb[1]],[elbb[2],elbb[3]]]
			for v in vt:
				if self.vInBB(v, spbb):
					col=True
					break
		return col
	
	def dataToRefresh(self):
		'''
		self.torefresh=[]
		for el in self.data:
			el['show']=False
			for sp in self.sprites:
				mv=sp.isMoving()
				if mv==True:
					col=self.testBB(el,sp)
					if col==True:
						self.torefresh.append(el)
						el['show']=True
						break
		for el in self.torefresh:
			index=self.data.index(el)+1
			for i in range(index,len(self.data)):
				subel=self.data[i]
				if subel['show']!=True:
					col=self.testBB(el,subel)
					if col==True and subel not in self.torefresh:
						self.torefresh.append(subel)
						subel['show']=True
		'''
		self.nbref=len(self.torefresh)
	
	def clear(self):
		dclear(self.c)
		drect(0,0,SCRN_W,SCRN_H,self.c)
	
	def clearSp(self):
		for sp in self.sprites:
			sp.clear(self.c)

	def plotSp(self):
		for sp in self.sprites:
			sp.plot()
	
	def plotBG(self):
		for el in self.data:
			if el['show']==True:
				if el['T']==X:
					dpixel(el['x'],el['y'],el['fill'])
				elif el['T']==R:
					drect(el['x'],el['y'],el['x']+el['w'],el['y']+el['h'],el['fill'])
				elif el['T']==L:
					dline(el['x1'],el['y1'],el['x2'],el['y2'],el['fill'])
				elif el['T']==C:
					dcircle(el['cx'],el['cy'],el['r'], el['fill'],el['bord'])
				elif el['T']==E:
					dellipse(el['cx']-el['rx'],el['cy']-el['ry'],el['cx']+el['rx'],el['cy']+el['ry'],el['fill'],el['bord'])
				elif el['T']==P:
					dpoly(el['points'],el['fill'],el['bord'])
				elif el['T']==I:
					dsubimage(el['x'],el['y'],el['img'],el['sx'],el['sy'],el['w'],el['h'])
	
	def resetG(self):
		self.torefresh=[]
		for el in self.data:
			el['show']=True
	
	# A surcharger sans oublier le super
	def reset(self):
		self.resetG()
	
	# A surcharger
	def sim(self):
		for sp in self.sprites:
			sp.move()
		return None
	
	# A surcharger
	def onkeydown(self,e):
		# On gère les événements clavier ici
		pass
	
	# A surcharger
	def onkeyup(self,e):
		# On gère les événements clavier ici
		pass
	
	def redraw(self):
		self.plotBG()
		self.plotSp()
		drect(0,0,30,20,C_BLACK)
		draw_string(1,1,"{}".format(self.dtic),(255,255,255),"medium")
		drect(366,0,396,20,C_BLACK)
		draw_string(367,1,"{}".format(self.nbref),(255,255,255),"medium")
	
	def run(self):
		self.nextScene=None
		self.initBB()
		self.tic=0
		self.dtic=0
		self.pt=time.time()
		self.nt=self.pt
		self.tt=self.pt
		self.resetG()
		self.torefresh=self.data
		self.clear()
		self.plotBG()
		self.plotSp()
		dupdate()
		self.l=1
		while self.l==1:
			self.nt=time.time()
			if self.nt > self.pt+DELAY:
				self.pt=self.nt
				self.tic=self.tic+1
				if self.nt > self.tt+1.0:
					self.tt=self.nt
					self.dtic=self.tic
					self.tic=0
				self.clearSp()
				self.dataToRefresh()
				res=self.sim()
				self.redraw()
				dupdate()
				while 1:
					e = pollevent()
					if e.type == KEYEV_NONE:
						break
					if e.type == KEYEV_DOWN:
						self.onkeydown(e)
						break
					if e.type == KEYEV_UP:
						self.onkeyup(e)
						break

		if self.nextScene!=None:
			self.nextScene.run()
	
	def stop(self,nextScene):
		self.l=0
		self.nextScene=nextScene
	
	# A surcharger
	def getData(self):
		data={'t':None,'spt':[]}
		for sp in self.sprites:
			data['spt'].append(sp.getData())
		return data
	
	# A surcharger
	def loadData(self,data):
		self.sprites=[]
		for sp in data['spt']:
			if sp['t']=='ply':
				nsp=Player(0,0,20,20)
				nsp.loadData(sp)
				self.addSprite(nsp)
			else:
				nsp=Sprite(0,0,20,20)
				nsp.loadData(sp)
				self.addSprite(nsp)

# Ajouter scènes à image pour les écrans d'intro