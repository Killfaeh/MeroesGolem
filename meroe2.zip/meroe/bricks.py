import math
from gint import *

from imgtiles import *

X=0
R=1
L=2
C=3
E=4
P=5
I=6

TILE=20
DTILE=10
QTILE=5
ROUND=2

def createCorneredRect(x,y,w,h,c):
	return [x,y+c,x,y+h-c,x+c,y+h,x+w-c,y+h,x+w,y+h-c,x+w,y+c,x+w-c,y,x+c,y]

def genTiles(x,y,w,h,tw,th,c):
	x=x*TILE
	y=y*TILE
	ell=[]
	for i in range(h):
		for j in range(w):
			tile={'T':R,'x':x+j*tw,'y':y+i*th,'w':tw,'h':th,'fill':c}
			ell.append(tile)
	return ell

def genBricks(x,y,w,h,sx,sy):
	x=x*TILE
	y=y*TILE
	ell=[]
	for i in range(h):
		for j in range(w):
			tile={'T':I,'x':x+j*TILE,'y':y+i*TILE,'w':TILE,'h':TILE,'sx':sx,'sy':sy,'img':imgtiles}
			ell.append(tile)
	return ell

def genCircles(x,y,w,sx,sy,c):
	x=x*TILE
	y=y*TILE
	ell=[]
	for i in range(w):
		tile={'T':I,'x':x+i*TILE,'y':y,'w':TILE,'h':TILE,'sx':sx,'sy':sy,'img':imgtiles}
		ell.append(tile)
	tile={'T':R,'x':x-2,'y':y-4,'w':w*TILE+4,'h':5,'fill':c}
	ell.append(tile)
	tile={'T':R,'x':x-2,'y':y+TILE-1,'w':w*TILE+4,'h':5,'fill':c}
	ell.append(tile)
	return ell

def genRect(x,y,w,h,c):
	if c!=None:
		return [{'T':R,'x':x,'y':y,'w':w,'h':h,'fill':c}]
	else:
		return [{'x':x,'y':y,'w':w,'h':h}]

def genCol(x,y):
	x=x*TILE
	y=y*TILE
	ell=[]
	return ell

def genDoor(x,y):
	x=x*TILE
	y=y*TILE
	return [{'T':R,'x':x-DTILE,'y':y-2*TILE,'w':TILE,'h':2*TILE,'fill':C_BLACK}]

clouds=[]